﻿// This program will write the name, address and telephone
// number of the programmer.

//Rus Hoffman

#include <iostream>
using namespace std;

int main()
{
	cout << "Rus Hoffman" << endl;
	cout << "New Hall North" << endl;
	cout << "Cookeville, Tennessee 38505" << endl;
	cout << "(615) 627-8025" << endl;

	return 0;
	
}