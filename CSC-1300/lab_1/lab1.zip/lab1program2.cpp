//Prints two messages
//Rus Hoffman and Eric Waggoner

#include <iostream>
using namespace std;

int main (){
	cout << "Today is a great day for a lab exercise";
	cout << endl << "We will have fun creating and fixing this lab!";
	
	return 0;
}