//Prints Hello World
//Rus Hoffman and Eric Waggoner

#include <iostream>
using namespace std;

int main (){
	cout << "Hello World,  this is Rus and Eric!" << endl;
	return 0;
}